package com.bittercode.model;

public enum UserRole {
    CUSTOMER, SELLER
}
